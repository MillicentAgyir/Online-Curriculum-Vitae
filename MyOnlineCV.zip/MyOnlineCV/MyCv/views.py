from django.shortcuts import render

from django.shortcuts import render
from django.http import HttpResponse
from . import forms
from django.core.mail import send_mail

from MyCv.models import *


def index(request):

    personal_info = Basic_info.objects.first()
    portfolios = portfolio.objects.all()
    portfolio_categories = Portfolio_categories.objects.all()
    skills = Professional_skill.objects.all()
    work_experience = Work_experience.objects.all()
    education = Education.objects.all()
    references = Reference.objects.all()
    success =""
    
  
    if request.method == "POST":
        # saving data from form 
        formValues = forms.ContactForm(request.POST)
        if formValues.is_valid():
            newMessage = Message()
            newMessage.name = formValues.cleaned_data["name"]
            newMessage.subject = formValues.cleaned_data["subject"]
            newMessage.email = formValues.cleaned_data["email"]
            newMessage.text = formValues.cleaned_data["text"]
            newMessage.save()
            
            send_mail(
            formValues.cleaned_data["subject"],
            formValues.cleaned_data["text"],
            formValues.cleaned_data["email"],
            ['agyirnana@gmail.com'],
            fail_silently=False,
            )
            
            success = "Message sent"  
    
    data = {
        "personal_info": personal_info,
        "portfolios" : portfolios,
        "skills" : skills,
        'portfolio_categories' : portfolio_categories,
        "work_experience" : work_experience,
        "education" : education,
        "references" : references,
        "contact_form" : forms.ContactForm,
        "success" : success
    }
           
    return render(request,'index.html',context=data)


