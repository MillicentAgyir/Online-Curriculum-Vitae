from django.db import models

class Basic_info(models.Model):
    name = models.CharField(max_length=256)
    email = models.CharField(max_length=256)
    phone = models.CharField(max_length=256)
    address = models.CharField(max_length=256)
    age = models.IntegerField()
    language = models.CharField(max_length=256)
    about = models.TextField()
    image = models.ImageField()
    job_title = models.CharField(max_length=256)
    facebook_acc = models.CharField(max_length=256)
    instagram_acc = models.CharField(max_length=256)
    twitter_acc = models.CharField(max_length=256)

    def __str__(self):
        return self.name

class Professional_skill(models.Model):
    profession_name = models.CharField(max_length=256)
    year_of_experience = models.IntegerField()

    def __str__(self):
        return self.profession_name

class Portfolio_categories(models.Model):
    name = models.CharField(max_length=256)

    def __str__(self):
        return self.name

class portfolio(models.Model):
    portfolio_name = models.CharField(max_length=256)
    portfolio_url = models.URLField()
    portfolio_image = models.ImageField()
    portfolio_category = models.ForeignKey(Portfolio_categories,on_delete=models.CASCADE)

    def __str__(self):
        return self.portfolio_name

class Work_experience(models.Model):
    job_title = models.CharField(max_length=256)
    job_duration = models.CharField(max_length=256)
    company = models.CharField(max_length=256)
    job_description = models.TextField()

    def __str__(self):
        return self.job_title

class Education(models.Model):
    name_of_school = models.CharField(max_length=256)
    duration = models.CharField(max_length=256)
    course_name = models.CharField(max_length=256)
    course_description = models.TextField()

    def __str__(self):
        return self.name_of_school

class Reference(models.Model):
    name = models.CharField(max_length=256)
    job_title = models.CharField(max_length=256)
    summary = models.TextField()
    image = models.ImageField()

    def __str__(self):
        return self.name

class Message(models.Model):
    name = models.CharField(max_length=256)
    subject = models.CharField(max_length=256)
    email = models.CharField(max_length=256)
    text = models.TextField()
    

    def __str__(self):
        return self.name
