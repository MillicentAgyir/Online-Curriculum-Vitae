from django import forms
from django.forms.widgets import EmailInput, Textarea 
from MyCv.models import Message

class ContactForm(forms.Form):
    
    model = Message
    name = forms.CharField(
        widget=forms.TextInput(
        attrs={
        'class':'form-control',
        'placeholder':'Name'
        }
    )
    )
    subject = forms.CharField(
        widget=forms.TextInput(
        attrs={
        'class':'form-control',
        'placeholder':'Subject'
        }
    )
    )
    email = forms.EmailField(
        widget=forms.EmailInput(
        attrs={
        'class':'form-control',
        'placeholder':'Email'
        }
        )
    )
    text = forms.CharField(widget=Textarea(
        attrs={
        'class':'form-control',
        'placeholder':'Your Message',
        'cols':'4',
        'rows': '3'
        }
    ))
    

    