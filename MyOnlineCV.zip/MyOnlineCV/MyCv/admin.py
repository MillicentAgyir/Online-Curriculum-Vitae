from django.contrib import admin

from .models import *

# Register your models here.
admin.site.register(Basic_info)
admin.site.register(portfolio)
admin.site.register(Portfolio_categories)
admin.site.register(Professional_skill)
admin.site.register(Work_experience)
admin.site.register(Education)
admin.site.register(Reference)
admin.site.register(Message)


