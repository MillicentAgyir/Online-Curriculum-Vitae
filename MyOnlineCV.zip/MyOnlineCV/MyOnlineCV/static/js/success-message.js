document.getElementById("submit-button").addEventListener("click", function(event){
    event.preventDefault();
    var form = document.querySelector("form");
    var data = new FormData(form);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", form.action);
    xhr.onload = function(){
      if(xhr.status === 200){
        // Display the success message
        var message = document.getElementById("success-message");
        message.innerHTML = "Message sent";
        message.classList.remove("d-none");
        setTimeout(function(){
          message.classList.add("d-none");
        },3000);
      }
    }
    xhr.send(data);
  });
  